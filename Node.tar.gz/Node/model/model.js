'use strict'

var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var movieSchema = Schema({


    name: String,
    year: Number,
    popularity: Number,
    imagen: String,
    category: [String],
    description: String,
    phrase: String


});

module.exports = mongoose.model('Movie', movieSchema);