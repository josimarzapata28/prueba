'use strict'

var express = require('express');
var controllermovie = require('../controllers/movie');
var controllerOtros = require('../controllers/otros');

var router = express.Router();

router.post('/saveMovie', controllermovie.saveMovie);
router.get('/movie/:id', controllermovie.getMovie);
router.get('/movies', controllermovie.getMovies);
router.put('/Update/:id', controllermovie.updateMovie);
router.delete('/Delete/:id', controllermovie.deleteMovie);
router.get('/peli/:id', controllerOtros.getpeli);


module.exports = router;