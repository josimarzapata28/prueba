var express = require('express');
var bodyParser = require('body-parser');

var app = express();

//archivos de ruta

var Movie_router = require('./routes/movie');

//midleware

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

//CORS

//rutas
app.use('/api', Movie_router);

//------------//

module.exports = app;