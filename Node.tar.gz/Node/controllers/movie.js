'use strict'

var modelMovie = require('../model/model');


var controller = {

    saveMovie: function(req, res) {

        var movie = modelMovie();
        let params = req.body;

        movie.name = params.name;
        movie.year = params.apellido;
        movie.populatiry = params.populatiry;
        movie.imagen = params.imagen;
        movie.category = params.category;
        movie.description = params.description;
        movie.phrase = params.phrase;

        movie.save((err, movieStored) => {

            if (err) return res.status(500).send({ message: "Error al Guardar Documento" });

            if (!movieStored) return res.status(404).send({ message: "No Se ha Podido Guardar La pelicula" });

            return res.status(200).send({ movie: movieStored });
        });

    },

    getMovie: function(req, res) {


        var movieId = req.params.id;

        modelMovie.findById(movieId, (err, movie) => {

            if (err) return res.status(500).send({ message: "Error al devolver el Dato" });

            if (!movie) return res.status(404).send({ message: "el proyecto no existe" });

            return res.status(200).send({ movie })
        });
    },
    getMovies: function(req, res) {
        modelMovie.find({}).exec((err, movies) => {
            if (err) return res.status(500).send({ message: "Error al devolver el Dato" });

            if (!movies) return res.status(404).send({ message: "el proyecto no existe" });

            return res.status(200).send({ movies })
        });
    },

    updateMovie: function(req, res) {

        var movieId = req.params.id;
        var update = req.body;

        modelMovie.findByIdAndUpdate(movieId, update, (err, movieUpdate) => {
            if (err) return res.status(500).send({ message: "Error al  Actualizar" });

            if (!movieUpdate) return res.status(404).send({ message: "no existe el proyecto para actualizar" });

            return res.status(200).send({
                movie: movieUpdate
            })
        });
    },

    deleteMovie: function(req, res) {
        var movieId = req.params.id;

        modelMovie.findByIdAndRemove(movieId, (err, movieDelete) => {
            if (err) return res.status(500).send({ message: "Error al  borrer" });

            if (!movieDelete) return res.status(404).send({ message: "no existe el proyecto para actualizar" });

            return res.status(200).send({
                movie: movieDelete
            })
        });
    }
}

module.exports = controller;