var model = require('../model/model');


var movie = new model();

module.exports = {

    getpeli: function(req, res) {

        movie.findById(req.params.id)
            .then((movie) => {
                return movie
            })
            .catch((e) => {
                res.send(e);
            })

    }
}